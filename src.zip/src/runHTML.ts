///////////////////////////////////////////////////////////////////////
//                                                                   //
//                                                                   //
//                                                                   //
//                 This file is used to test the                     //
//                    display and play a game                        //
//                                                                   //
//                                                                   //
//                                                                   //
///////////////////////////////////////////////////////////////////////

import * as W from "./world.js";
import * as D from "./display.js";
import * as M from "./motor.js";
import * as A from "./actor.js";
import * as I from './interaction.js';

const mode = "html";

const initRunning: I.Running = {
  isRunning: false,
  buildTower: false,
};

//const newWorld = W.map_1();
const newWorld = W.map_1();
D.displayWorld(newWorld, mode);

const world = M.solvePhaseByName("spawn", newWorld);
D.displayWorld(world, mode);

/////////////////////////////////////////////////////////////////////////

async function runGameLoop(world: W.World, mode: I.Mode) {
  let previousWorld = world;
  if (world.score.playerLives > 0 && initRunning.isRunning){
    
    if (initRunning.buildTower) {
      if (D.display.canvas !== null){
        D.display.canvas.addEventListener("click", (event: MouseEvent) => {
          if (D.display.canvas !== null){
            const rect = D.display.canvas.getBoundingClientRect();
            const x = Math.floor((event.clientX - rect.left) / D.display.tileSize);
            const y = Math.floor((event.clientY - rect.top) / D.display.tileSize);
            const point: W.Point = { x, y };
            // Check if the player has enough money to build the tower
            if (world.score.money >= 50) {
              world = A.spawnSmallTower(world, point);
              D.displayWorld(world, mode);
            } else {
              D.displayNotEnoughMoney();
            }
          } 
        });
        initRunning.buildTower = false;
      }
    }

    if (D.display.canvas !== null){
      D.display.canvas.addEventListener("click", (event: MouseEvent) => {
        if (D.display.canvas !== null){
          const rect = D.display.canvas.getBoundingClientRect();
          const x = Math.floor((event.clientX - rect.left) / D.display.tileSize);
          const y = Math.floor((event.clientY - rect.top) / D.display.tileSize);
      
          const point: W.Point = { x, y };
      
          // Check if the player has enough money to build the cactus
          if (world.score.money >= 20) {
            world = A.spawnCactusAtPoint(world, point);
            D.displayWorld(world, mode);
          } else {
            D.displayNotEnoughMoney();
          }
        }
      });
    }

    const phases = M.gameEngine(world.score);

    for (const phase of phases){
      world = M.solvePhaseByName(phase, world);
      D.displayWorld(world, mode);
      await new Promise((resolve) => setTimeout(resolve, 100));

      // Manages mobs flashing when hit
      const actorsWithDecreasedHP = differenceHP(previousWorld, world);
      for (const actor of actorsWithDecreasedHP) {
        await D.displayHit(actor, world);
      }

      // Updates previousWorld for next iteration
      previousWorld = JSON.parse(JSON.stringify(world));
    }

    runGameLoop(world, mode);
  }
  else{
    D.displayGameOverMessage();
  }
}

/*
const playButton = document.getElementById("playButton");
if (playButton) {
playButton.addEventListener("click", () => {
    isRunning = true;
    runGameLoop(world);
});
} else {
console.error("Le bouton Play est introuvable.");
}

const stopButton = document.getElementById("stopButton");
if (stopButton) {
  stopButton.addEventListener("click", () => {
    isRunning = false;
  });
} else {
  console.error("Le bouton Stop est introuvable.");
}

const buildButton = document.getElementById("buildButton");
if (buildButton) {
  buildButton.addEventListener("click", () => {
    buildTower = true;
    buildButton.textContent = buildTower ? "Building" : "Build";
  });
} else {
  console.error("Le bouton Build est introuvable.");
}

function resetBuildButton() {
    if (buildButton) {
      buildButton.textContent = "Build";
      buildTower = false;
    }
}*/


export function differenceHP(previousWorld: W.World, world: W.World): A.Actor[] {
  const actorsWithDecreasedHP: A.Actor[] = [];

  for (const previousActor of previousWorld.actors) {
    const currentActor = world.actors.find(
      (actor) =>
        (actor.pos.x === previousActor.pos.x &&
          actor.pos.y === previousActor.pos.y) ||
        (Math.abs(actor.pos.x - previousActor.pos.x) === 1 &&
          actor.pos.y === previousActor.pos.y) ||
        (actor.pos.x === previousActor.pos.x &&
          Math.abs(actor.pos.y - previousActor.pos.y) === 1) &&
        actor.tile.tileType === previousActor.tile.tileType
    );

    if (
      currentActor &&
      currentActor.tile.tileType === W.mobTileType &&
      currentActor.hp < previousActor.hp
    ) {
      actorsWithDecreasedHP.push(currentActor);
    }
  }

  return actorsWithDecreasedHP;
}

const callbacks = {
  play: () => {
    initRunning.isRunning = true;
    runGameLoop(world, mode);
  },
  stop: () => {
    initRunning.isRunning = false;
  },
  build: () => {
    initRunning.buildTower = true;
  }
};

I.setupInteraction(mode, callbacks);

