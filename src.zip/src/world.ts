///////////////////////////////////////////////////////////////////////
//                                                                   //
//                                                                   //
//                                                                   //
//            This file gathers all the data structures              //
//               and functions related to the world                  //
//                                                                   //
//                                                                   //
//                                                                   //
///////////////////////////////////////////////////////////////////////


import * as A from "./actor.js";
import * as S from "./score.js";

type Point = {x: number; y: number};

type WorldSize = {width: number; height: number};

type World = {
    size: WorldSize;
    score: S.Score;
    actors: A.Actor[];
    landscapes: Landscape[];
};

type Landscape = {
  name: string;
  heuristic: number;
  pos: Point;
  tile: Tile;
};

type TileType = {
  render: (displayMode: "html" | "console", object: Landscape | A.Actor) => string;
};
  
type Tile = {
    tileType: TileType;
};

//Create a Tile with a TileType
function createTile(tileType: TileType): Tile {
  return {
    tileType,
  };
}

//Return an empty world initialized with the width and the height
const worldEmpty = (width: number, height: number): World => ({
    size: { width: width, height: height },
    actors: [],
    score: S.player,
    landscapes: [],
});

//Add an actor to the world but doesn't control if it's possible to add it
function addActor(actor: A.Actor, world: World): World {
  const newActors = world.actors.concat(actor);
  return {
    ...world,
    actors: newActors,
  };
}

//Compute distance between two points
const distance = (p1: Point, p2: Point): number => {
    const dx = p1.x - p2.x;
    const dy = p1.y - p2.y;
    return Math.sqrt(dx * dx + dy * dy);
};
  
const getActorsAroundPoint = (
    centerPoint: Point,
    maxDistance: number,
    world: World
    ): A.Actor[] => {
    return world.actors.filter((actor) => {
        const actorDistance = distance(centerPoint, actor.pos);
        return actorDistance <= maxDistance;
    });
};

function createWorld(height: number, width: number): World {
  const actorsEmpty: A.Actor[] = [];

  // Create an array of landscapes filled with grass
  const landscapesGrass: Landscape[] = [];
  for (let y = 0; y < height; y++) {
    for (let x = 0; x < width; x++) {
      const pos: Point = { x, y };
      landscapesGrass.push({
        name: "grass",
        heuristic: 0,
        pos: pos,
        tile: grassTile,
      });
    }
  }
  return {
    size: {width: width, height: height},
    actors: actorsEmpty,
    score: S.player,
    landscapes: landscapesGrass,
  };
}

function createLandscape(name: string, pos: Point, tile: Tile): Landscape {
  return {
    name,
    heuristic: 0,
    pos,
    tile,
  };
}

function createLandscape1(name: string, heuristic: number, pos: Point, tile: Tile): Landscape {
  return {
    name,
    heuristic,
    pos,
    tile,
  };
}

//Add path without the heuristique (0 everywhere)
function addPath(position: Point, world: World): World {
  const newLandscapes = world.landscapes.map((landscape: Landscape) => {
    if (landscape.pos.x === position.x && landscape.pos.y === position.y)
      return createLandscape1("path", 0, position, createTile(pathTileType));
    return landscape;
  });

  return {
    ...world,
    landscapes: newLandscapes,
  };
}

function addEntry(position: Point, world: World): World {
  const newLandscapes = world.landscapes.map((landscape: Landscape) => {
    if (landscape.pos.x === position.x && landscape.pos.y === position.y)
      return createLandscape1("entry", 0, position, createTile(entryTileType));
    return landscape;
  });

  return {
    ...world,
    landscapes: newLandscapes,
  };
}

function addExit(position: Point, world: World): World {
  const newLandscapes = world.landscapes.map((landscape: Landscape) => {
    if (landscape.pos.x === position.x && landscape.pos.y === position.y)
      return createLandscape1("exit", 0, position, createTile(exitTileType));
    return landscape;
  });

  return {
    ...world,
    landscapes: newLandscapes,
  };
}

function map_1(): World {

  let world = createWorld(20, 35);

  // Initialize path for mobs
  for (let i = 0; i < 7; i++) world = addPath({ x: i, y: 12 }, world);
  for (let i = 12; i > 3; i--) world = addPath({ x: 7, y: i }, world);
  for (let i = 7; i < 14; i++) world = addPath({ x: i, y: 4 }, world);
  for (let i = 4; i < 17; i++) world = addPath({ x: 14, y: i }, world);
  for (let i = 14; i < 26; i++) world = addPath({ x: i, y: 17 }, world);
  for (let i = 17; i > 5; i--) world = addPath({ x: 26, y: i }, world);
  for (let i = 26; i < 35; i++) world = addPath({ x: i, y: 6 }, world);

  // Place towers
  const world1 = addActor(A.createActor({x: 5, y: 10}, 200, createTile(towerTileType), A.smallTowerActions), world);
  const world2 = addActor(A.createActor({x: 11, y: 10}, 0, createTile(towerTileType), A.smallTowerActions), world1);
  const world3 = addActor(A.createActor({x: 20, y: 12}, 0, createTile(towerTileType), A.smallTowerActions), world2);
  const world4 = addActor(A.createActor({x: 30, y: 4}, 0, createTile(towerTileType), A.smallTowerActions), world3);

  const world5 = addEntry({x: 0, y: 12}, world4);
  const world6 = addExit({x: 34, y: 6}, world5);

  return heuristic(world6);
}

function displayLandscapes(world: World): void {
  for (const landscape of world.landscapes) {
    if (landscape.name === "entry" || landscape.name === "path" || landscape.name === "exit"){
      console.log('landscape:');
      console.log('  name:', landscape.name);
      console.log('  pos:', landscape.pos);
      console.log(' heuristique:', landscape.heuristic);
    }
  }
}

function createHeuristic(world: World): World{
  const pathLandscapeList: Landscape[] = [];

  // Finding the Landscape Entry and Exit
  const entryLandscape = world.landscapes.find(landscape => landscape.tile.tileType === entryTileType);
  const exitLandscape = world.landscapes.find(landscape => landscape.tile.tileType === exitTileType);

  if (!entryLandscape || !exitLandscape) {
    console.error("Entry or Exit Landscape not found");
    return world;
  }

  let currentLandscape = entryLandscape;
  let lastmove: number = 0; // 0 (right), 1 (up), 2 (down)

  while (currentLandscape.tile.tileType !== exitTileType) {
    
    const right = currentLandscape.pos.x + 1;
    const up = currentLandscape.pos.y - 1;
    const down = currentLandscape.pos.y + 1;

    const landscapeAtRight = world.landscapes.find(landscape => landscape.pos.x === right && landscape.pos.y === currentLandscape.pos.y);

    /* If there is a path to the right */
    if (landscapeAtRight?.tile.tileType === pathTileType){
      pathLandscapeList.push(landscapeAtRight);
      currentLandscape = landscapeAtRight;
      lastmove = 0; //right
    }

    else{

      /* If the last move was to the right 
      So the mob can't go to the right anymore */
      if (lastmove === 0){
        const landscapeUp = world.landscapes.find(landscape => landscape.pos.x === currentLandscape.pos.x && landscape.pos.y === up);
        const landscapeDown = world.landscapes.find(landscape => landscape.pos.x === currentLandscape.pos.x && landscape.pos.y === down);
        
        /* If there is a path up */
        if (landscapeUp?.tile.tileType === pathTileType){
          pathLandscapeList.push(landscapeUp);
          currentLandscape = landscapeUp;
          lastmove = 1; //up
        }
        
        /* If the path is down */
        else if(landscapeDown?.tile.tileType === pathTileType){
          pathLandscapeList.push(landscapeDown);
          currentLandscape = landscapeDown;
          lastmove = 2; //down
        }
      }

      /* If the last move was up */
      else if (lastmove === 1){

        /* If there is a path to the right */
        if (landscapeAtRight?.tile.tileType === pathTileType){
          pathLandscapeList.push(landscapeAtRight);
          currentLandscape = landscapeAtRight;
          lastmove = 0; //right
        }

        else{
          const landscapeUp = world.landscapes.find(landscape => landscape.pos.x === currentLandscape.pos.x && landscape.pos.y === up);
          if (landscapeUp){
            pathLandscapeList.push(landscapeUp);
            currentLandscape = landscapeUp;
          }
        }
      }

      /* If the last move was down */
      else if (lastmove === 2){

        /* If there is a path to the right */
        if (landscapeAtRight?.tile.tileType === pathTileType){
          pathLandscapeList.push(landscapeAtRight);
          currentLandscape = landscapeAtRight;
          lastmove = 0; //right
        }

        else{
          const landscapeDown = world.landscapes.find(landscape => landscape.pos.x === currentLandscape.pos.x && landscape.pos.y === down);
          if (landscapeDown){
            pathLandscapeList.push(landscapeDown);
            currentLandscape = landscapeDown;
          }
        }
      }

    }
  }

  const length = pathLandscapeList.length;

  /* Change the heuristic of the Landscapes */
  for (let i = 0; i < length; i++) {
    pathLandscapeList[i].heuristic = length - i;
  }

  // Replace landscapes in the world with those with updated heuristics
  const updatedLandscapes = world.landscapes.map(landscape => {
    const updatedLandscape = pathLandscapeList.find(pathLandscape => pathLandscape.pos.x === landscape.pos.x && pathLandscape.pos.y === landscape.pos.y);
    return updatedLandscape || landscape;
  });

  // Return a new World object with updated landscapes
  return {
    ...world,
    landscapes: updatedLandscapes,
  };
}

//Create heuristic of the world
function heuristic(world: World): World {
  const landscapesH = world.landscapes.map((landscape: Landscape) => {
    //get the array of the paths around with 1 in radius
    const pathAround = getPathAround(landscape.pos, world, world.size.height);

    if (pathAround.find((ls: Landscape) => ls.pos.x === landscape.pos.x) === undefined) {
      return {
        ...landscape,
        heuristic: landscape.pos.x,
      };
    }

    else {
      const path = pathAround.find((ls: Landscape) => ls.pos.x === landscape.pos.x + 1);
      if (path !== undefined){
        const dist = distance(path.pos, landscape.pos);
        const heuris = landscape.pos.x + (1/(dist+1));
        return {
          ...landscape,
          heuristic: heuris,
        };
      }
      else{
        const exit = world.landscapes.find((ls: Landscape) => ls.name === "exit");
        if (exit !== undefined){
          const dist = distance(landscape.pos, exit.pos);
          return {
            ...landscape,
            heuristic: landscape.pos.x + (1/(dist+1))
          };
        }
        return landscape;
      }
    }
  });
  return {
    ...world,
    landscapes: landscapesH,
  };
}

//Get path around a landscape and inside the radius 
function getPathAround(point: Point, world: World, radius: number): Landscape[] {
  const landscapesInRadius = world.landscapes.filter((ls: Landscape) => distance(point, ls.pos) <= radius);
  return landscapesInRadius.filter((ls: Landscape) => ls.name === "path" || ls.name === "entry" || ls.name === "exit");
}

// Create TileTypes

const grassTileType: TileType = {
  render: (displayMode: "html" | "console", object: Landscape) => {
    if (displayMode === "html"){
      return "green";
    }
    else if (displayMode === "console"){
      return ".";
    }
    else {
      throw new Error('Pas de displayMode connu');
    }
  }
};

const pathTileType: TileType = {
  render: (displayMode: "html" | "console", object: Landscape) => {
    if (displayMode === "html"){
      return "lightgray";
    }
    else if (displayMode === "console"){
      return " ";
    }
    else {
      throw new Error('Pas de displayMode connu');
    }
  }
};

const entryTileType: TileType = {
  render: (displayMode: "html" | "console", object: Landscape) => {
    if (displayMode === "html"){
      return "yellow";
    }
    else if (displayMode === "console"){
      return "E";
    }
    else {
      throw new Error('Pas de displayMode connu');
    }
  }
};

const exitTileType: TileType = {
  render: (displayMode: "html" | "console", object: Landscape) => {
    if (displayMode === "html"){
      return "orange";
    }
    else if (displayMode === "console"){
      return "E";
    }
    else {
      throw new Error('Pas de displayMode connu');
    }
  }
};

const cactusTileType: TileType = {
  render: (displayMode: "html" | "console", object: Landscape) => {
    if (displayMode === "html"){
      return "black";
    }
    else if (displayMode === "console"){
      return "C";
    }
    else {
      throw new Error('Pas de displayMode connu');
    }
  }
};

const mobTileType: TileType = {
  render: (displayMode: "html" | "console", object: A.Actor) => {
    if (displayMode === "html"){
      return "red";
    }
    else if (displayMode === "console"){
      return "X";
    }
    else {
      throw new Error('Pas de displayMode connu');
    }
  }
};

const towerTileType: TileType = {
  render: (displayMode: "html" | "console", object: A.Actor) => {
    if (displayMode === "html"){
      return object.hp <= 0 ? "darkslategray" : "blue";
    }
    else if (displayMode === "console"){
      return object.hp <= 0 ? "0" : "I";
    }
    else {
      throw new Error('Pas de displayMode connu');
    }
  }
};

/*
const grassTileType: TileType = {
  render: (displayMode: "html" | "console", object: Landscape) => {
    const x = object.pos.x;
    const y = object.pos.y;

    if (displayMode === "html") {
      if (D.display.ctx !== null) {
        D.display.ctx.fillStyle = "green";
        D.display.ctx.fillRect(x * D.display.tileSize, y * D.display.tileSize, D.display.tileSize, D.display.tileSize);
      }
    } else if (displayMode === "console") {
      process.stdout.write("G");
    }
  },
};

const mobTileType: TileType = {
  render: (displayMode: "html" | "console", object: A.Actor) => {
    const x = object.pos.x;
    const y = object.pos.y;

    if (displayMode === "html") {
      if (D.display.ctx !== null) {
        D.display.ctx.fillStyle = "red";
        D.display.ctx.fillRect(x * D.display.tileSize, y * D.display.tileSize, D.display.tileSize, D.display.tileSize);
      }
    } else if (displayMode === "console") {
      process.stdout.write("M");
    }
  },
};

const towerTileType: TileType = {
  render: (displayMode: "html" | "console", object: A.Actor) => {
    const x = object.pos.x;
    const y = object.pos.y;

    if (displayMode === "html") {
      if (D.display.ctx !== null) {
        D.display.ctx.fillStyle = object.hp <= 0 ? "darkslategray" : "blue";
        D.display.ctx.fillRect(x * D.display.tileSize, y * D.display.tileSize, D.display.tileSize, D.display.tileSize);
      }
    } else if (displayMode === "console") {
      process.stdout.write("P");
    }
  },
};


const pathTileType: TileType = {
  render: (displayMode: "html" | "console", object: Landscape) => {
    const x = object.pos.x;
    const y = object.pos.y;

    if (displayMode === "html") {
      if (D.display.ctx !== null) {
        D.display.ctx.fillStyle = "lightgray";
        D.display.ctx.fillRect(x * D.display.tileSize, y * D.display.tileSize, D.display.tileSize, D.display.tileSize);
      }
    } else if (displayMode === "console") {
      process.stdout.write("P");
    }
  },
};

const entryTileType: TileType = {
  render: (displayMode: "html" | "console", object: Landscape) => {
    const x = object.pos.x;
    const y = object.pos.y;

    if (displayMode === "html") {
      if (D.display.ctx !== null) {
        D.display.ctx.fillStyle = "yellow";
        D.display.ctx.fillRect(x * D.display.tileSize, y * D.display.tileSize, D.display.tileSize, D.display.tileSize);
      }
    } else if (displayMode === "console") {
      process.stdout.write("E");
    }
  },
};

const exitTileType: TileType = {
  render: (displayMode: "html" | "console", object: Landscape) => {
    const x = object.pos.x;
    const y = object.pos.y;

    if (displayMode === "html") {
      if (D.display.ctx !== null) {
        D.display.ctx.fillStyle = "orange";
        D.display.ctx.fillRect(x * D.display.tileSize, y * D.display.tileSize, D.display.tileSize, D.display.tileSize);
      }
    } else if (displayMode === "console") {
      process.stdout.write("E1");
    }
  },
};

const cactusTileType: TileType = {
  render: (displayMode: "html" | "console", object: Landscape) => {
    const x = object.pos.x;
    const y = object.pos.y;

    if (displayMode === "html") {
      if (D.display.ctx !== null) {
        D.display.ctx.fillStyle = "black";
        D.display.ctx.fillRect(x * D.display.tileSize, y * D.display.tileSize, D.display.tileSize, D.display.tileSize);
      }
    } else if (displayMode === "console") {
      process.stdout.write("C");
    }
  },
};*/

// Create Tiles
const pathTile: Tile = {
  tileType: pathTileType
};

const grassTile: Tile = {
  tileType: grassTileType
};

const mobTile: Tile = {
  tileType: mobTileType
};

const towerTile: Tile = {
  tileType: towerTileType
};

const cactusTile: Tile = {
  tileType: cactusTileType
};

const exitTile: Tile = {
  tileType: exitTileType
};

function initStraightPath(world: World): World {
  const pathCoords = Array.from(
    { length: world.size.width },
    (_, i) => ({ x: i, y: Math.floor(world.size.height / 2) })
  );

  return pathCoords.reduce((accWorld, coord) => addPath(coord, accWorld), world);
}

function initRandomPath(world: World): World {
  const entryPos = { x: 0, y: Math.floor(world.size.height / 2) };
  const exitPos = { x: world.size.width - 1, y: Math.floor(world.size.height / 2) };

  const getRandomInt = (max: number) => Math.floor(Math.random() * max);

  let currentPos = { ...entryPos };

  while (currentPos.x !== exitPos.x || currentPos.y !== exitPos.y) {
    world = addPath(currentPos, world);

    const possibleDirections = [
      { x: currentPos.x + 1, y: currentPos.y }, // Right
      { x: currentPos.x, y: currentPos.y - 1 }, // Up
      { x: currentPos.x, y: currentPos.y + 1 }, // Down
    ].filter(
      (pos) =>
        pos.x >= 0 &&
        pos.y >= 0 &&
        pos.x < world.size.width &&
        pos.y < world.size.height &&
        !isPath(pos, world)
    );

    if (possibleDirections.length === 0) break;

    currentPos = possibleDirections[getRandomInt(possibleDirections.length)];
  }

  world = addPath(exitPos, world);
  world = addEntry(entryPos, world);
  world = addExit(exitPos, world);

  return world;
}


function placeRandomTowers(world: World, numTowers: number): World {
  const getRandomInt = (max: number) => Math.floor(Math.random() * max);

  for (let i = 0; i < numTowers; i++) {
    const x = getRandomInt(world.size.width);
    const y = getRandomInt(world.size.height);
    const pos = { x, y };

    // To not place towers in the way
    if (!isPath(pos, world)) {
      world = addActor(
        A.createActor(pos, 200, createTile(towerTileType), A.smallTowerActions),
        world
      );
    }
  }

  return world;
}

function generateMap(world: World): World {
  const worldWithPath = initRandomPath(world);
  const worldWithTowers = placeRandomTowers(worldWithPath, 10); 

  return heuristic(worldWithTowers);
}

function isPath(pos: Point, world: World): boolean {
  return world.landscapes.some(
    (landscape) => landscape.pos.x === pos.x && landscape.pos.y === pos.y && landscape.name === "path"
  );
}




export {
    Point,
    WorldSize,
    World,
    TileType,
    createTile,
    Tile,
    Landscape,
    pathTile,
    pathTileType,
    mobTile,
    mobTileType,
    addActor,
    getActorsAroundPoint,
    towerTile,
    towerTileType,
    displayLandscapes,
    getPathAround,
    grassTileType,
    grassTile,
    entryTileType,
    exitTileType,
    createWorld,
    map_1,
    worldEmpty,
    addPath,
    cactusTile,
    exitTile,
    cactusTileType,
    createLandscape,
    createLandscape1,
    generateMap,
    heuristic,
    distance,
};