///////////////////////////////////////////////////////////////////////
//                                                                   //
//                                                                   //
//                                                                   //
//            This file gathers the functions related                //
//                  to the display of the game                       //
//                                                                   //
//                                                                   //
//                                                                   //
///////////////////////////////////////////////////////////////////////

import * as W from "./world.js";
import * as A from "./actor.js";
import * as I from "./interaction.js";

function initializeCanvasContext(): CanvasRenderingContext2D | null {
  const canvas = typeof document !== 'undefined' ? document.getElementById("gameCanvas") as HTMLCanvasElement : null;

  if (!canvas) {
    console.error("Canvas element not found.");
    return null;
  }

  const ctx = canvas.getContext("2d");
  if (!ctx) {
    console.error("Canvas context is not available.");
    return null;
  }

  return ctx;
}

const display = {
  canvas: typeof document !== 'undefined' ? document.getElementById("gameCanvas") as HTMLCanvasElement : null,
  ctx: initializeCanvasContext(),
  tileSize: 32,
};

//Initialize a 2 dimensions grid in order to show the world in console
function initializeConsoleContext(): string[][] {
  const grid: string[][] = [];
  return grid;
}

let grid = initializeConsoleContext();

function displayWorld(world: W.World, displayMode: "html" | "console"): void {
  if (displayMode === "html"){
    displayHtml(world);
  }
  displayConsole(world);
}

//Initialise the grid for console
function displayConsole(world: W.World): void {
  const grid2: string[][] = Array.from(Array(world.size.height), () =>
    Array(world.size.width).fill(""));
    grid = grid2;
  fillWorld(world, "console");
  afficherGrille(grid);
  displayScore(world, "console");
}

//Function that fill the world with displayMode
function fillWorld(world: W.World, displayMode: "html" | "console"): void {
  for (const landscape of world.landscapes){
    const render = landscape.tile.tileType.render(displayMode, landscape);
    if (displayMode === "html") {
      if (display.ctx !== null) {
        display.ctx.fillStyle = render;
        display.ctx.fillRect(landscape.pos.x * display.tileSize, landscape.pos.y * display.tileSize, display.tileSize, display.tileSize);
      }
    } else if (displayMode === "console") {
      grid[landscape.pos.y][landscape.pos.x] = render;
    }
  }

  for (const actor of world.actors){
    const render = actor.tile.tileType.render(displayMode, actor);
    if (displayMode === "html") {
      if (display.ctx !== null) {
        display.ctx.fillStyle = render;
        display.ctx.fillRect(actor.pos.x * display.tileSize, actor.pos.y * display.tileSize, display.tileSize, display.tileSize);
      }
    } else if (displayMode === "console") {
      grid[actor.pos.y][actor.pos.x] = render;
    }
  }
}

//Initialise the html
function displayHtml(world: W.World): void {

  if (!display.ctx) {
    console.error("Canvas context is not available.");
    return;
  }
  if (!display.canvas) {
    console.error("Canvas context is not available.");
    return;
  }

  // Adjust canvas size based on map size and tile size
  display.canvas.width = world.size.width * display.tileSize;
  display.canvas.height = world.size.height * display.tileSize;

  // Clear the canvas
  display.ctx.clearRect(0, 0, display.canvas.width, display.canvas.height);

  displayScore(world, "html");

  display.ctx.fillStyle = "lightgray";
  display.ctx.fillRect(display.tileSize, display.tileSize, display.tileSize, display.tileSize);
  
  fillWorld(world, "html");

  // Add life bar for each mob type actor
  if (display.canvas && display.ctx) {
    for (const actor of world.actors) {
      if (actor.actions && actor.actions.move !== undefined) {
        drawHealthBar(actor, display.ctx);
      }
    }
  }
}

// In the Display module (D)
function drawHealthBar(actor: A.Actor, ctx: CanvasRenderingContext2D): void {
  const { pos, hp } = actor;
  const maxHP = 100; // Replace with max HP value for mobs
  const barWidth = 30;
  const barHeight = 5;
  const barX = pos.x * display.tileSize + (display.tileSize - barWidth) / 2;
  const barY = pos.y * display.tileSize - 10;

  // Draw the outline of the life bar
  ctx.strokeStyle = "#000";
  ctx.strokeRect(barX, barY, barWidth, barHeight);

  // Draw the inner life bar
  const fillWidth = (hp / maxHP) * barWidth;
  ctx.fillStyle = hp > maxHP * 0.6 ? "#0f0" : hp > maxHP * 0.3 ? "#ff0" : "#f00";
  ctx.fillRect(barX, barY, fillWidth, barHeight);
}


function displayGameOverMessage() {
  if (!display.ctx) {
    console.error("Canvas context is not available.");
    return;
  }

  display.ctx.font = "48px Arial";
  display.ctx.fillStyle = "red";
  display.ctx.textAlign = "center";
  display.ctx.fillText("Game Over", display.ctx.canvas.width / 2, display.ctx.canvas.height / 2);
}

function displayNotEnoughMoney() {
  const notEnoughMoneyElement = document.getElementById("notEnoughMoney");

  if (notEnoughMoneyElement) {
    notEnoughMoneyElement.textContent = "Not enough money";
    notEnoughMoneyElement.style.display = "block";

    // Erase the message after a certain time
    setTimeout(() => {
      notEnoughMoneyElement.style.display = "none";
    }, 2000);
  } else {
    console.error("L'élément notEnoughMoney est introuvable.");
  }
}

const buildMode = false; // Export buildMode so you can access it in testDisplay.ts

async function displayHit(actor: A.Actor, world: W.World) {
  const ctx = display.ctx;

  if (ctx && display.canvas) {
    const originalFillStyle = ctx.fillStyle;
    ctx.fillStyle = "aqua";
    ctx.fillRect(
      actor.pos.x * display.tileSize,
      actor.pos.y * display.tileSize,
      display.tileSize,
      display.tileSize
    );

    await new Promise((resolve) => setTimeout(resolve, 200));

    displayWorld(world, "html");

    ctx.fillStyle = originalFillStyle;
  }
}

function afficherGrille(grille: string[][]) {
  grille.forEach((ligne) => {
    console.log(ligne.join(" "));
  });
}

function displayScore(world: W.World, mode: I.Mode): void {
  if (mode === "console"){
    console.log('money:', world.score.money);
    console.log('playerLives:', world.score.playerLives);
    console.log('score:', world.score.score);
  }
  
  else if (mode === "html"){
    // Update the lives display element
    const livesDisplay = document.getElementById("livesDisplay");
    if (livesDisplay) {
      livesDisplay.textContent = `Lives: ${world.score.playerLives}`;
    }

    // Update the score display element
    const scoreDisplay = document.getElementById("scoreDisplay");
    if (scoreDisplay) {
      scoreDisplay.textContent = `Score: ${world.score.score}`;
    }

    // Update the money display element
    const moneyDisplay = document.getElementById("moneyDisplay");
    if (moneyDisplay) {
      moneyDisplay.textContent = `Money: ${world.score.money}`;
    }
  }
}

export {
  displayWorld,
  displayNotEnoughMoney,
  displayGameOverMessage,
  displayHit,
  display,
  grid,
  afficherGrille,
};