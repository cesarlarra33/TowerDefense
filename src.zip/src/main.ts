
///////////////////////////////////////////////////////////////////////
//                                                                   //
//                                                                   //
//                                                                   //
//            This file lauches the game and runs the gameloop       //
//                                                                   //
//                                                                   //
//                                                                   //
//                                                                   //
///////////////////////////////////////////////////////////////////////


import * as W from "./world.js";
import * as M from "./motor.js";
import * as D from "./display.js";
import * as I from "./interaction.js";

console.log("Console game");

const mode: I.Mode = "console";

//const newWorld = W.map_1();
const newWorld = W.map_1();
D.displayWorld(newWorld, mode);

const world = M.solvePhaseByName("spawn", newWorld);
D.displayWorld(world, mode);

const initRunning: I.Running = {
    isRunning: false,
    buildTower: false,
};

async function runGameLoop(world: W.World, mode: I.Mode) {
  if (world.score.playerLives > 0 && initRunning.isRunning){

    const phases = M.gameEngine(world.score);

    for (const phase of phases){
      world = M.solvePhaseByName(phase, world);
      D.displayWorld(world, mode);
      await new Promise((resolve) => setTimeout(resolve, 10));
    }
    runGameLoop(world, mode);
  }
    else{
      console.log('Partie perdue !\n');
      return;
    }
}

const callbacks = {
    play: () => {
      initRunning.isRunning = true;
      console.log('Lancement de la partie...');
      runGameLoop(world, mode);
    },
    stop: () => {
      initRunning.isRunning = false;
      console.log('Partie finie...');
      return;
    },
    build: () => {
      initRunning.buildTower = true;
      console.log('Vous pouvez construire une tour...');
    },
  };

  I.setupInteraction(mode, callbacks);
















