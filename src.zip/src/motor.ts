import * as W from "./world.js";
import * as A from "./actor.js";
import * as P from "./phase.js";
import * as S from "./score.js";

////////////////////////////////////////////////////////////////////////////////
///////////////////////////Game engine implementation///////////////////////////
////////////////////////////////////////////////////////////////////////////////

//Type resolvePhase
type PhaseSolver = (updatedActors: A.Actor[], world: W.World) => W.World;

//Type to associate a key with each resolved phase
type PhaseMap = {
  [key: string]: PhaseSolver;
};

//Associates a key of type string to each phase to be able to call them easily
const phaseMap: PhaseMap = {
  "spawn": resolveSpawn,
  "move": resolveMove,
  "target": resolveTarget,
  "cactus": resolveHitcactus
};

//Solves several phases according to the string array given in parameter and returns the corresponding world
function solvePhasesByName(phaseNames: string[], world: W.World): W.World[] {
  return phaseNames.map((phase: string) => {
    return solvePhaseByName(phase, world);
  });
}

function solvePhaseByName(phaseName: string, world: W.World): W.World {
  const phaseFunction = P.phaseFunctions[phaseName];
  if (phaseFunction){
    const resolvePhaseFunction = phaseMap[phaseName];
    const actors = phaseFunction(world);
    if (resolvePhaseFunction){
      return resolvePhaseFunction(actors, world);
    }
    else {
      throw new Error(`Resolve phase function "${phaseName}" not found`);
    }
  } else {
    throw new Error(`Phase function "${phaseName}" not found`);
  }
}

////////////////////////////////////////////////////////////////////////////////
//////////////////Functions for Resolving Phase Conflicts///////////////////////
////////////////////////////////////////////////////////////////////////////////

//Solves the move phase
function resolveMove(updatedActors: A.Actor[], world: W.World): W.World {
  //Find exit in the world
  const exit = world.landscapes.find((landscape: W.Landscape) => landscape.name === "exit");
  if (exit === undefined){
    throw new Error('No exit in the world !');
  }

  //Filter of the actors that reach the exit position, if so, lost 1 playerLives
  const lengthInit = updatedActors.length;
  const actors = updatedActors.filter((actor: A.Actor) => {
    return (actor.pos !== exit.pos);
  });
  const lengthAfter = actors.length;
  if (lengthInit !== lengthAfter){
    const newScore = {
      ...world.score,
      playerLives: world.score.playerLives - (lengthInit - lengthAfter),
    };
    return {
      ...world,
      actors: actors,
      score: newScore,
    };
  }

  return {
    ...world,
    actors: actors,
  };
}

function resolveSpawn(updatedActors: A.Actor[], world: W.World): W.World {
  //Find spawn in the map
  const spawn = world.landscapes.find((ls: W.Landscape) => ls.name === "entry");
  if (spawn === undefined){
    throw new Error('Pas de spawn définit sur la map');
  }

  if (world.actors.find((actor: A.Actor) => {
    return actor.pos.x === spawn.pos.x && actor.pos.y === spawn.pos.y;
  })){
    return world;
  }

  else{
    return {
      ...world,
      actors: updatedActors,
    };
  }
}

function resolveTarget(updatedActors: A.Actor[], world: W.World): W.World {
  //Filter all of the mobs that have hp >= 0
  const initActors = updatedActors.length;
  const actorsWithLife = updatedActors.filter((actor: A.Actor) => (actor.actions && actor.actions.move !== undefined && actor.hp > 0) || (actor.hp >= 0));
  const afterActors = actorsWithLife.length;

  const newScore = {
    playerLives: world.score.playerLives,
    money: world.score.money + 5*(initActors - afterActors),
    score: world.score.score + (initActors - afterActors)
  };

  return {
    ...world,
    actors: actorsWithLife,
    score: newScore,
  };
}

function resolveHitcactus(updatedActors: A.Actor[], world: W.World): W.World {
  const actorsWithLife = updatedActors.filter((actor: A.Actor) => (actor.actions && actor.actions.move !== undefined && actor.hp > 0) || (actor.hp >= 0));
  const cactusHitted = actorsWithLife.map((actor: A.Actor) => {
    if (actor.actions && actor.actions.hit !== undefined){
      return {
        ...actor,
        hp: actor.hp - 50,
      };
    }
    return actor;
  });

  return {
    ...world,
    actors: cactusHitted,
  };
}

// Base game phase sequence
const basePhaseSequence: string[] = ['spawn', 'move', 'cactus', 'move', 'cactus', 'move', 'cactus', 'move', 'cactus', 'move', 'cactus', 'move', 'cactus', 'target', 'move', 'cactus', 'move', 'cactus', 'move', 'cactus', 'move', 'cactus', 'move', 'cactus', 'move', 'cactus', 'target'];

// Function to add additional 'spawn' phase recursively
const addSpawns = (sequence: string[], count: number): string[] => {
  if (count === 0) return sequence;
  const spawnIndex: number = 4 + (basePhaseSequence.length - 1) * (count - 1);
  const newSequence: string[] = [...sequence.slice(0, spawnIndex), 'spawn', ...sequence.slice(spawnIndex)];
  return addSpawns(newSequence, count - 1);
};

// Game engine function
function gameEngine(score: S.Score): string[] {
  const additionalSpawns: number = Math.floor(score.score / 7);  // adjust this value based on desired difficulty
  return addSpawns(basePhaseSequence, additionalSpawns);
}

export {
  PhaseSolver,
  phaseMap,
  PhaseMap,
  resolveMove,
  resolveSpawn,
  resolveTarget,
  resolveHitcactus,
  solvePhasesByName,
  solvePhaseByName,
  gameEngine,
};