///////////////////////////////////////////////////////////////////////
//                                                                   //
//                                                                   //
//                                                                   //
//      This file gathers the structures and functions related       //
//         functions related to  to the lives, money,                //
//                    score of the player                            //
//                                                                   //
//                                                                   //
///////////////////////////////////////////////////////////////////////


type Score = {
    playerLives : number; 
    money : number; 
    score: number;
}

const player: Score = {
    playerLives: 10, 
    money: 100,
    score: 0,
  };

//Theses functions will be called when a mob mades it to the end, or if the player buys a turret/ kills a mob
function removeLifeFromPlayer(player: Score): Score {
return { ...player, playerLives: player.playerLives - 1 };
}

function removeMoneyFromPlayer(player: Score, price: number): Score{
    return{...player, money: player.money - price}; 
}

function addMoneyToPlayer(player: Score, gain: number): Score{
    return{...player, money: player.money + gain};
}

export {
    Score, 
    player, 
    removeLifeFromPlayer, 
    removeMoneyFromPlayer, 
    addMoneyToPlayer,
}; 





