///////////////////////////////////////////////////////////////////////
//                                                                   //
//                                                                   //
//                                                                   //
//               This file gathers the structures and                //
//               functions related to the game phases                //
//                                                                   //
//                                                                   //
//                                                                   //
///////////////////////////////////////////////////////////////////////

import * as W from "./world.js";
import * as A from "./actor.js";


type Phase = (world: W.World) => A.Actor[];

const phaseFunctions: { [key: string]: Phase } = {
  "move": movePhase,
  "spawn": spawnPhase,
  "target": targetPhase,
  "cactus": cactusPhase,
};

/*Take the world in entry and check for all of the actors if one want to move. Return new actors array with new 
wanted positions*/
function movePhase(world: W.World): A.Actor[] {
  return world.actors.map((actor: A.Actor) => {
      if (actor.actions && actor.actions.move !== undefined){
        return A.move(actor, world);
      }
      else{
        return actor;
      }
  });
}

//Spawn mob TODO: find the right pos to spawn
function spawnPhase(world: W.World): A.Actor[] {
  //Find the spawn
  const spawnLandscape = world.landscapes.find((landscape: W.Landscape) => landscape.name === "entry");
  if (spawnLandscape === undefined){
    throw new Error('Pas de spawn !');
  }
  const newMob = A.createActor(spawnLandscape.pos, 100, W.createTile(W.mobTileType), A.mobActions);
  return world.actors.concat(newMob);
}


//Target phase change the HP of all the mobs that have been shooted in the world.
function targetPhase(world: W.World): A.Actor[] {
  //Tab of shooted mobs with a lower hp
  const shootedActors = world.actors
    .filter((actor: A.Actor) => actor.actions && actor.actions.shoot !== undefined && actor.hp > 0)
    .map((actor: A.Actor) => actor.actions.shoot(actor, world));

  const shootedMobs = shootedActors.filter((actor: A.Actor) => actor.actions && actor.actions.move !== undefined);

  const updatedActors = world.actors.map((actor: A.Actor) => {
    const matchingActor = shootedMobs.find((a: A.Actor) => a.pos.x === actor.pos.x && a.pos.y === actor.pos.y);
    return matchingActor ? matchingActor : actor;
  });

  return updatedActors;
}

function cactusPhase(world: W.World): A.Actor[] {
  //Tab of shooted mobs with a lower hp
  const hittedActors = world.actors
    .filter((actor: A.Actor) => actor.actions && actor.actions.hit !== undefined && actor.hp > 0)
    .map((actor: A.Actor) => actor.actions.hit(actor, world));

  const hittedMobs = hittedActors.filter((actor: A.Actor) => actor.actions && actor.actions.move !== undefined);

  const updatedActors = world.actors.map((actor: A.Actor) => {
    const matchingActor = hittedMobs.find((a: A.Actor) => a.pos.x === actor.pos.x && a.pos.y === actor.pos.y);
    return matchingActor ? matchingActor : actor;
  });

  return updatedActors;
}

export {
    Phase,
    phaseFunctions,
    movePhase,
    spawnPhase,
    targetPhase,
    cactusPhase,
};