///////////////////////////////////////////////////////////////////////
//                                                                   //
//                                                                   //
//                                                                   //
//            This file deals with the user's interactions           //
//                 with the machine in order to run a game           //
//                                                                   //
//                                                                   //
//                                                                   //
///////////////////////////////////////////////////////////////////////




export type Mode = "html" | "console";

type Running = {
    isRunning: boolean,
    buildTower: boolean,
};

/*export type ReadlineModule = {
    createInterface: (options: { input: NodeJS.ReadableStream; output: NodeJS.WritableStream }) => {
      on: (event: string, listener: (input: string) => void) => void;
      close: () => void;
    };
};*/

const handleHtmlInteraction = (mode: Mode, callbacks: Record<string, () => void>) => {
    if (mode !== "html") {
      return;
    }
  
    const playButton = document.getElementById("playButton");
    const stopButton = document.getElementById("stopButton");
    const buildButton = document.getElementById("buildButton");
  
    if (playButton) {
      playButton.addEventListener("click", callbacks.play);
    } else {
      console.error("Le bouton Play est introuvable.");
    }
  
    if (stopButton) {
      stopButton.addEventListener("click", callbacks.stop);
    } else {
      console.error("Le bouton Stop est introuvable.");
    }
  
    if (buildButton) {
      buildButton.addEventListener("click", () => {
        callbacks.build();
        buildButton.textContent = "Building";
      });
    } else {
      console.error("Le bouton Build est introuvable.");
    }
  };
  
  async function handleConsoleInteraction(callbacks: Record<string, () => void>) {
      
    let readline = null;
      
    if (typeof process !== 'undefined') {
        readline = await import('readline');
    }

    if (!readline) {
      console.error('Cette fonction ne peut pas être utilisée dans un navigateur web.');
      return;
    }
    
    const rl = readline.createInterface({
      input: process.stdin,
      output: process.stdout
    });
  
    console.log("Appuyez sur 'p' pour Play, 's' pour Stop, 'b' pour Build...");
  
    rl.on('line', (input: string) => {
        const args = input.split(' ');
        const command = args[0];
      
        switch(command) {
          case 'p':
            callbacks.play();
            rl.close();
            break;
          case 's':
            callbacks.stop();
            rl.close();
            break;
          case 'b':
            callbacks.build();
            rl.close();
            break;
          default:
            console.log("Commande non reconnue.");
        }
      });
  }
  
  export const setupInteraction = (mode: Mode, callbacks: Record<string, () => void>) => {
    if (mode === "html") {
        handleHtmlInteraction(mode, callbacks);
    }
    else if (mode === "console") {
        handleConsoleInteraction(callbacks);
    }
    else {
        console.error(`Unsupported mode: ${mode}`);
    }
  };

export {
    Running,
};