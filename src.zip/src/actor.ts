///////////////////////////////////////////////////////////////////////
//                                                                   //
//                                                                   //
//                                                                   //
//            This file gathers all the data structures              //
//                 and functions related to actors                   //
//                                                                   //
//                                                                   //
//                                                                   //
///////////////////////////////////////////////////////////////////////



import * as W from "./world.js";
import * as S from "./score.js";

//The 'Action' type defines an action that an actor possesses within the game.
type Action = (actor: Actor, world: W.World) => Actor;

/*
  The 'Actions' type is an object that maps a string key to an 'Action'. 
  This allows for easy access and execution of any action possessed by an actor.
*/
type Actions = {
  [key: string]: Action;
};

/*  
  The 'Actor' type defines an entity in the game world, characterized by its position ('pos'), 
  health points ('hp'), visual representation ('tile'), and the set of actions it can perform ('actions').
*/
type Actor = {
  pos: W.Point;
  hp: number;
  tile: W.Tile;
  actions: Actions;
};

/////////////////////////////////////////////////////////////////////////////
/////////////////////////   ACTORS IMPLEMENTATIONS  /////////////////////////
/////////////////////////////////////////////////////////////////////////////

/* 
  `spawnActor` checks the health of an actor. If hp <= 0, it sets hp to 200.
  It returns the original or modified actor.
*/
function spawnActor(actor: Actor, world: W.World): Actor {
  if (!actor || !world) {
    throw new Error("Both actor and world must be defined.");
  }
  return actor.hp > 0 ? actor : { ...actor, hp: 200 };
}

///////////////////////////////
/* Implementation of a cactus */
///////////////////////////////


/* 
  `cactusActions` defines the possible actions a cactus actor can take.
  It can either spawn or shoot.
*/
const cactusActions: Actions = {
  spawn: (cactus: Actor, world: W.World) => spawnActor(cactus, world),
  hit: (cactus: Actor, world: W.World) => shoot(cactus, world, 1, 10),
};

/* 
  `spawnCactusAtPoint` spawns a cactus actor at a specific point on the world.
  If no landscape is present at the point, an error is thrown.
  If a path is present and no other actor occupies the same position, 
  a cactus is spawned and the world's money score is decreased by 10.
*/
function spawnCactusAtPoint(world: W.World, point: W.Point): W.World {
  const existActor = world.actors.find((actor: Actor) => actor.pos.x === point.x && actor.pos.y === point.y);
  const isOnPath = world.landscapes.find((ls: W.Landscape) => ls.pos.x === point.x && ls.pos.y === point.y);
  if (isOnPath === undefined){
    throw new Error('Il doit y avoir un landscape à cet emplacement');
  }
  if (existActor === undefined && isOnPath.name === "path"){
    const newWorld = W.addActor(createActor(point, 50, W.cactusTile, cactusActions), world);
    const newScore = {...world.score, money: world.score.money - 10};
    return {
      ...newWorld,
      score: newScore,
    };
  }
  return world;
}


////////////////////////////////
/* Implementation for the mob */
////////////////////////////////

/* 
  `mobActions` defines the possible actions a mob actor can take.
  It can move around the world.
*/
const mobActions: Actions = {
  move: (Mob: Actor, world: W.World) => move(Mob, world),
};

/* 
  `move` function updates the position of an actor in the world.
  The actor moves to the closest path or to the exit if it is within reach.
  The actor only moves if the new position is not occupied by another actor.
  If no valid move is possible, the actor remains in its current position.
*/
function move(actor: Actor, world: W.World): Actor {
  if (!actor || !world) {
    throw new Error("Both actor and world must be defined.");
  }
  
  //Get path around the actor with a radius of 1
  const paths = W.getPathAround(actor.pos, world, 1);
  if (paths.length === 0){
    return actor;
  }
  
  //Find the path that is the most close to the exit
  const path = paths.reduce((landscape1: W.Landscape, landscape2: W.Landscape) => {
    return landscape1.heuristic + landscape1.pos.x > landscape2.heuristic + landscape2.pos.x ? landscape1 : landscape2;
  });

  //Verify that there is no other actor in the new position
  const actorInSamePosition = world.actors.find((actor: Actor) => actor.pos.x === path.pos.x && actor.pos.y === path.pos.y);
  if (actorInSamePosition === undefined){
    return {
      ...actor,
      pos: path.pos,
    };
  }

  return {
    ...actor,
  };
}


/////////////////////////////////
/* Implementation of the Tower */
/////////////////////////////////

/* We need 4 tower on those position : 
x:5, y:10
x:11 y:10
x:20 y:12
x:30 y:4
*/

/* 
  `smallTowerActions` defines the actions for a small tower actor. 
  It can spawn and shoot with a radius of 7 and a damage level of 80.
*/
const smallTowerActions: Actions = {
  // Re-spawn the tower with 100 HP if its HP drops to 0
  spawn: (tower: Actor, world: W.World) => spawnActor(tower, world),
  
  // Shoot targets within a radius of 7 with a damage level of 25
  shoot: (tower: Actor, world: W.World) => {
    const newTower = shoot(tower, world, 7, 25);
    return { ...tower, ...newTower };
  },
};

/* 
  `medTowerActions` defines the actions for a medium tower actor. 
  It can spawn and shoot with a radius of 10 and a damage level of 90.
*/
const medTowerActions: Actions = {
  // Re-spawn the tower with 100 HP if its HP drops to 0
  spawn: (tower: Actor, world: W.World) => spawnActor(tower, world),
  
  // Shoot targets within a radius of 10 with a damage level of 90
  shoot: (tower: Actor, world: W.World) => {
    const newTower = shoot(tower, world, 10, 70);
    return { ...tower, ...newTower };
  },
};

/* 
  `largeTowerActions` defines the actions for a large tower actor. 
  It can spawn and shoot with a radius of 15 and a damage level of 100.
*/
const largeTowerActions: Actions = {
  // Re-spawn the tower with 100 HP if its HP drops to 0
  spawn: (tower: Actor, world: W.World) => spawnActor(tower, world),
  
  // Shoot targets within a radius of 15 with a damage level of 100
  shoot: (tower: Actor, world: W.World) => {
    const newTower = shoot(tower, world, 15, 90);
    return { ...tower, ...newTower };
  },
};


/* 
  `spawnTowerAtPoint` generates a tower at a given point in the world 
  if there is enough money to afford the cost of the tower.
  It takes in the current world state, a point, the tower's actions, 
  and the cost of the tower as parameters.
*/
function spawnTowerAtPoint(world: W.World, point: W.Point, actions: Actions, scoreCost: number): W.World {
  // Trouvez l'index de la tour située au point donné
  const towerIndex = world.actors.findIndex(actor => actor.pos.x === point.x && actor.pos.y === point.y && actor.actions && actor.actions.spawn !== undefined);

  // Si aucune tour n'est trouvée, retournez le monde inchangé
  if (towerIndex === -1) {
    return world;
  }

  // Sinon, mettez à jour la tour et créez un nouvel objet World avec la tour mise à jour
  const tower = world.actors[towerIndex];
  const updatedTower = spawnActor(tower, world);
  const newActors = [
    ...world.actors.slice(0, towerIndex),
    { ...updatedTower, actions }, // Mettre à jour les actions de la tour
    ...world.actors.slice(towerIndex + 1),
  ];

  // Déduire le coût en points de score
  const newScore: S.Score = {
    playerLives: world.score.playerLives,
    money: world.score.money - scoreCost,
    score: 0,
  };

  return { ...world, actors: newActors, score: newScore };
}

/* 
  `spawnSmallTower`, `spawnMedTower`, and `spawnLargeTower` are helper functions 
  that spawn a small, medium, or large tower at a given point in the world, respectively.
  The cost to spawn each type of tower is 40, 50, and 80, respectively.
*/
function spawnSmallTower(world: W.World, point: W.Point): W.World {
  return spawnTowerAtPoint(world, point, smallTowerActions, 25);
}

function spawnMedTower(world: W.World, point: W.Point): W.World {
  return spawnTowerAtPoint(world, point, medTowerActions, 50);
}

function spawnLargeTower(world: W.World, point: W.Point): W.World {
  return spawnTowerAtPoint(world, point, largeTowerActions, 80);
}


//Return an actor Mob within the radius of the tower with a lower hp and with the most right position in the world
function shoot(tower: Actor, world: W.World, radius: number, damage: number): Actor {
  const actorsInRadius = world.actors.filter((actor: Actor) => {
    // Calculate the distance between the tower and the actor (mob)
    const distance = W.distance(tower.pos, actor.pos);
    
    // If the actor is within the shooting radius of the tower, removes damage HP
    return distance <= radius && actor.actions && actor.actions.move !== undefined;
  });
  if (actorsInRadius.length !== 0){
    const actorDamaged = findActorMostToTheEnd(actorsInRadius);
    return {
      ...actorDamaged,
      hp: actorDamaged.hp - damage,
    };
  }
  return tower;
}

/////////////////////////////////////////////////////////////////////////////
/////////////////////// END OF ACTORS IMPLEMENTATION ////////////////////////
/////////////////////////////////////////////////////////////////////////////

//Find an actor that is most to the right in the world
function findActorMostToTheEnd(actors: Actor[]): Actor {
  if (actors.length === 0) {
    throw new Error('Cannot find most to the right actor in an empty array.');
  }
  
  return actors.reduce((mostToTheRightActor: Actor , currentActor: Actor) => {
    if (!mostToTheRightActor || currentActor.pos.x > mostToTheRightActor.pos.x) {
      return currentActor;
    }
    return mostToTheRightActor;
  }, actors[0]);
}


//On regarde si deux points sont des voisins.
function isNeighbor(p1: W.Point, p2: W.Point){
  if ((Math.abs(p1.x - p2.x) <= 1 || Math.abs(p1.y - p2.y) <= 1) &&( (Math.abs(p1.x - p2.x) === 0 || Math.abs(p1.y - p2.y) === 0))){
    return true;
  } 
  return false;
}

//On cherche les points voisins.
function getLandscapePoint(world: W.World, actor: Actor): W.Point[] {
  const neighbors = world.landscapes.filter((a: W.Landscape) => isNeighbor(actor.pos, a.pos));
  const neighbors2 = neighbors.filter((a: W.Landscape) => a.name === "path");
  const positions = neighbors2.map(x=>x.pos);
  return positions;
}

function getLandscape(world: W.World, actor: Actor): W.Landscape[] {
  const neighbors = world.landscapes.filter((a: W.Landscape) => isNeighbor(actor.pos, a.pos));
  const neighbors2 = neighbors.filter((a: W.Landscape) => a.name === "path");
  return neighbors2;
}

function createActor(pos: W.Point, hp: number, tile: W.Tile, actions: Actions): Actor {
  return {
    pos,
    hp,
    tile,
    actions,
  };
}

/////////////////////////////////////////////////////////////////////////////
///////////////////////////////// DISPLAY ///////////////////////////////////
/////////////////////////////////////////////////////////////////////////////

function displayActors(actors: Actor[]): void {
  for (const actor of actors) {
    console.log('Actor:');
    console.log('  Position:', actor.pos);
    console.log('  HP:', actor.hp);
    console.log('  Actions:');
    for (const actionKey in actor.actions) {
      console.log(`    ${actionKey}`);
    }
  }
}

function displayPoints(point: W.Point[]): void {
  console.log('Points : ');
  for (const p of point) {
    console.log('Point:');
    console.log('  x:', p.x);
    console.log(' y:', p.y);
    
    
  }
}
function displayLandscapes(landscapes: W.Landscape[]): void {
  console.log('Landscapes : ');
  for (const l of landscapes) {
    displayLandscape(l);
  }
}

function displayLandscape(l: W.Landscape): void {
  console.log('Landscape : ');
    console.log('Name:', l.name);
    console.log('Pos:', l.pos);    
}

function displayPath(landscapes: W.Landscape[]): void {
  console.log('Landscapes : ');
  for (const l of landscapes) {
    if (l.tile.tileType === W.pathTileType) {
      console.log('Name:', l.name);
      console.log('Pos:', l.pos);
      console.log('Heuristic:', l.heuristic);
    }
  }
}


export {
  Action,
  Actions,
  Actor,
  cactusActions,
  displayPoints,
  displayLandscape,
  displayLandscapes,
  spawnTowerAtPoint,
  mobActions,
  move,
  isNeighbor,
  getLandscape,
  getLandscapePoint,
  spawnActor,
  shoot,
  createActor,
  displayActors,
  displayPath,
  smallTowerActions,
  medTowerActions,
  largeTowerActions,
  spawnSmallTower,
  spawnMedTower,
  spawnLargeTower,
  spawnCactusAtPoint,
};