import * as W from "../src/world.js";
import * as A from "../src/actor.js";
import * as S from "../src/score.js";

describe("Tests pour les fonctions de création et de modification d'un monde", () => {
    test("Test de la fonction worldEmpty", () => {
      const width = 10;
      const height = 20;
      const world = W.worldEmpty(width, height);
      expect(world.size.width).toBe(width);
      expect(world.size.height).toBe(height);
      expect(world.actors).toEqual([]);
      expect(world.score).toEqual(S.player);
      expect(world.landscapes).toEqual([]);
    });
  
    test("Test de la fonction addActor", () => {
      const actor: A.Actor = { pos: { x: 1, y: 1 }, hp: 10, tile: W.mobTile, actions: {} };
      const worldEmpty: W.World = {
        size: { width: 10, height: 10 },
        actors: [],
        score: S.player,
        landscapes: [],
      };
      const world = W.addActor(actor, worldEmpty);
      expect(world.actors.length).toBe(1);
      expect(world.actors[0]).toBe(actor);
    });
  
    test("Test de la fonction createWorld", () => {
      const width = 5;
      const height = 10;
      const world = W.createWorld(height, width);
      expect(world.size.width).toBe(width);
      expect(world.size.height).toBe(height);
      expect(world.actors).toEqual([]);
      expect(world.score).toEqual(S.player);
      expect(world.landscapes.length).toBe(width * height);
      world.landscapes.forEach((landscape) => {
        expect(landscape.name).toBe("grass");
      });
    });
  
    test("Test de la fonction createLandscape", () => {
      const pos: W.Point = { x: 1, y: 1 };
      const tile: W.Tile = W.mobTile;
      const landscape = W.createLandscape("test", pos, tile);
      expect(landscape.name).toBe("test");
      expect(landscape.pos).toBe(pos);
      expect(landscape.tile).toBe(tile);
    });
  
    test("Test de la fonction createLandscape1", () => {
      const pos: W.Point = { x: 1, y: 1 };
      const tile: W.Tile = W.mobTile;
      const heuristic = 10;
      const landscape = W.createLandscape1("test", heuristic, pos, tile);
      expect(landscape.name).toBe("test");
      expect(landscape.pos).toBe(pos);
      expect(landscape.tile).toBe(tile);
      expect(landscape.heuristic).toBe(heuristic);
    });
  
    test("Test de la fonction addPath", () => {
      const position: W.Point = { x: 1, y: 1 };
      const worldEmpty: W.World = {
        size: { width: 10, height: 10 },
        actors: [],
        score: S.player,
        landscapes: [{ name: "grass", heuristic: 0, pos: { x: 1, y: 1 }, tile: W.mobTile }],
      };
      const world = W.addPath(position, worldEmpty);
      expect(world.landscapes[0].name).toBe("path");
    });
});
  


