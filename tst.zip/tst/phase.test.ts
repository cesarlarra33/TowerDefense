import * as W from "../src/world.js";
import * as P from "../src/phase.js";
import * as A from "../src/actor.js";
import { expect, jest } from "@jest/globals";


describe("movePhase", () => {
    it("returns an empty array if there are no actors in the world", () => {
      const world: W.World = {
        size: { width: 10, height: 10 },
        actors: [],
        score: { playerLives: 3, money: 100, score: 0 },
        landscapes: [],
      };
      const result = P.movePhase(world);
      expect(result).toEqual([]);
    });
  
    it("returns the same actors array if no actor has a 'move' action", () => {
      const actors: A.Actor[] = [
        { pos: { x: 1, y: 1 }, hp: 10, tile: W.mobTile, actions: A.mobActions },
        { pos: { x: 2, y: 2 }, hp: 10, tile: W.mobTile, actions: A.mobActions },
        { pos: { x: 3, y: 3 }, hp: 10, tile: W.mobTile, actions: A.mobActions },
      ];
      const world: W.World = {
        size: { width: 10, height: 10 },
        actors,
        score: { playerLives: 3, money: 100, score: 0 },
        landscapes: [],
      };
      const result = P.movePhase(world);
      expect(result).toEqual(actors);
    });
  
    it("updates the positions of actors with a 'move' action", () => {
      const actors: A.Actor[] = [
        { pos: { x: 1, y: 1 }, hp: 10, tile: W.mobTile, actions: A.mobActions },
        { pos: { x: 2, y: 2 }, hp: 10, tile: W.mobTile, actions: A.mobActions },
        { pos: { x: 3, y: 3 }, hp: 10, tile: W.mobTile, actions: A.mobActions },
      ];
      const world: W.World = {
        size: { width: 10, height: 10 },
        actors: actors,
        score: { playerLives: 3, money: 100, score: 0 },
        landscapes: [],
      };
      const result = P.movePhase(world);
      expect(result).toEqual([
        A.move(actors[0], world),
        A.move(actors[1], world),
        actors[2],
      ]);
    });
  });

 