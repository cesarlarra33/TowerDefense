import { truncate } from "fs";
import * as A from "../src/actor.js";
import * as W from "../src/world.js";

describe('Actor', () => {
    describe('spawnActor', () => {
      const actor = {
        pos: { x: 1, y: 1 },
        hp: 100,
        tile: W.mobTile,
        actions: {}
      };
      const world = W.worldEmpty(5, 5);
  
      test('should set hp to 200 if hp is less than or equal to 0', () => {
        const newActor = A.spawnActor({ ...actor, hp: 0 }, world);
        expect(newActor.hp).toBe(200);
  
        const newActor2 = A.spawnActor({ ...actor, hp: -10 }, world);
        expect(newActor2.hp).toBe(200);
      });
  
      test('should not modify hp if hp is greater than 0', () => {
        const newActor = A.spawnActor({ ...actor, hp: 50 }, world);
        expect(newActor.hp).toBe(50);
  
        const newActor2 = A.spawnActor({ ...actor, hp: 100 }, world);
        expect(newActor2.hp).toBe(100);
      });
  
      test('should not modify the original object', () => {
        const originalActor = { ...actor };
        A.spawnActor(actor, world);
        expect(actor).toEqual(originalActor);
      });
    });

    describe('spawnCactusAtPoint', () => {
        const cactusTile = W.createTile(W.cactusTileType);
        const cactusActions = A.cactusActions;
        const world: W.World = {
            size: { width: 5, height: 5 },
            actors: [],
            landscapes: [
              { pos: { x: 0, y: 0 }, name: 'path', heuristic: 0, tile: W.grassTile },
              { pos: { x: 0, y: 1 }, name: 'path', heuristic: 0, tile: W.grassTile },
              { pos: { x: 0, y: 2 }, name: 'water', heuristic: 0, tile: W.grassTile },
            ],
            score: { playerLives: 10, money: 100, score: 0 },
          };
    
        test('should throw an error if there is no landscape at the point', () => {
        expect(() => A.spawnCactusAtPoint(world, { x: 0, y: 3 })).toThrow('Il doit y avoir un landscape à cet emplacement');
        });
    
        test('should not spawn a cactus if there is already an actor at the point', () => {
        const actor = { pos: { x: 0, y: 0 }, hp: 100, tile: W.mobTile, actions: {} };
        const worldWithActor = { ...world, actors: [actor] };
        const newWorld = A.spawnCactusAtPoint(worldWithActor, { x: 0, y: 0 });
        expect(newWorld).toEqual(worldWithActor);
        });
    
        test('should not spawn a cactus if the point is not on a path', () => {
        const newWorld = A.spawnCactusAtPoint(world, { x: 0, y: 2 });
        expect(newWorld).toEqual(world);
        });
    
        test('should spawn a cactus and subtract 10 money from score', () => {
        const newWorld = A.spawnCactusAtPoint(world, { x: 0, y: 1 });
        expect(newWorld.actors.length).toBe(1);
        expect(newWorld.actors[0].pos).toEqual({ x: 0, y: 1 });
        expect(newWorld.actors[0].hp).toBe(50);
        expect(newWorld.actors[0].tile).toStrictEqual(cactusTile);
        expect(newWorld.actors[0].actions).toStrictEqual(cactusActions);
        expect(newWorld.score.money).toBe(90);
        });
    
        test('should return a new world object', () => {
        const newWorld = A.spawnCactusAtPoint(world, { x: 0, y: 1 });
        expect(newWorld).not.toBe(world);
        });
    });
      
    describe('move', () => {
        const actor: A.Actor = {
          pos: { x: 2, y: 2 },
          hp: 100,
          tile: { tileType: { render: () => null } },
          actions: {},
        };
      
        const world: W.World = {
          size: { width: 5, height: 5 },
          score: { playerLives: 3, money: 0, score: 0 },
          actors: [],
          landscapes: [
            { name: 'path', heuristic: 0, pos: { x: 0, y: 2 }, tile: { tileType: { render: () => null } } },
            { name: 'path', heuristic: 1, pos: { x: 1, y: 2 }, tile: { tileType: { render: () => null } } },
            { name: 'path', heuristic: 2, pos: { x: 2, y: 2 }, tile: { tileType: { render: () => null } } },
            { name: 'path', heuristic: 3, pos: { x: 3, y: 2 }, tile: { tileType: { render: () => null } } },
            { name: 'path', heuristic: 4, pos: { x: 4, y: 2 }, tile: { tileType: { render: () => null } } },
            { name: 'exit', heuristic: 4.5, pos: { x: 4, y: 4 }, tile: { tileType: { render: () => null } } },
          ],
        };
      
        it('should move to closest path', () => {
          const newActor = A.move(actor, world);
          expect(newActor.pos).toEqual({ x: 3, y: 2 });
        });
      
        it('should move to exit if on exit', () => {
          const actorOnExit: A.Actor = { ...actor, pos: { x: 4, y: 4 } };
          const newActor = A.move(actorOnExit, world);
          expect(newActor.pos).toEqual({ x: 4, y: 4 });
        });
      
        it('should not move to position occupied by another actor', () => {
          const worldWithActor: W.World = {
            ...world,
            actors: [
              { pos: { x: 3, y: 2 }, hp: 100, tile: { tileType: { render: () => null } }, actions: {} },
            ],
          };
          const newActor = A.move(actor, worldWithActor);
          expect(newActor.pos).toEqual(actor.pos);
        });
      });
      
      describe('spawnTowerAtPoint', () => {
        const tower: A.Actor = {
          pos: { x: 2, y: 2 },
          hp: 100,
          tile: { tileType: { render: () => null } },
          actions: A.medTowerActions,
        };
      
        const world: W.World = {
          size: { width: 5, height: 5 },
          score: { playerLives: 3, money: 100, score: 0 },
          actors: [tower],
          landscapes: [
            { name: 'path', heuristic: 1, pos: { x: 0, y: 2 }, tile: { tileType: { render: () => null } } },
            { name: 'path', heuristic: 1, pos: { x: 1, y: 2 }, tile: { tileType: { render: () => null } } },
            { name: 'path', heuristic: 1, pos: { x: 2, y: 2 }, tile: { tileType: { render: () => null } } },
            { name: 'path', heuristic: 1, pos: { x: 3, y: 2 }, tile: { tileType: { render: () => null } } },
            { name: 'path', heuristic: 1, pos: { x: 4, y: 2 }, tile: { tileType: { render: () => null } } },
            { name: 'exit', heuristic: 0, pos: { x: 4, y: 4 }, tile: { tileType: { render: () => null } } },
          ],
        };
      
        it('should not spawn tower if no tower at point', () => {
          const newWorld = A.spawnTowerAtPoint(world, { x: 1, y: 1 }, {}, 10);
          expect(newWorld).toEqual(world);
        });
      
        it('should spawn tower with updated actions and decreased score', () => {
          const newWorld = A.spawnTowerAtPoint(world, { x: 2, y: 2 }, A.medTowerActions, 10);
          expect(newWorld.actors[0].actions).toEqual(A.medTowerActions);
          expect(newWorld.score.money).toEqual(90);
        });
      
        it('should not spawn tower if not enough score', () => {
          const newWorld = A.spawnTowerAtPoint(world, { x: 2, y: 2 }, A.medTowerActions, 110);
          expect(newWorld).toEqual(world);
        });
      });
      

      describe('Test shoot', () => {
        const mob1: A.Actor = {
          pos: { x: 2, y: 0 },
          hp: 100,
          tile: W.mobTile,
          actions: A.mobActions,
        };
        const mob2: A.Actor = {
          pos: { x: 3, y: 2 },
          hp: 50,
          tile: W.mobTile,
          actions: A.mobActions,
        };
        const tower: A.Actor = {
          pos: { x: 2, y: 1 },
          hp: 100,
          tile: W.towerTile,
          actions: A.medTowerActions,
        };
        const world: W.World = {
          size: { width: 5, height: 5 },
          score: { playerLives: 10, money: 100, score: 0 },
          actors: [mob1, mob2, tower],
          landscapes: [],
        };
      
        test('Test shoot damages a mob within radius', () => {
          const newMob1 = A.shoot(tower, world, 1, 20);
          expect(newMob1.hp).toBe(80);
      
          const newMob2 = A.shoot(tower, world, 2, 20);
          expect(newMob2.hp).toBe(30);
        });
      
        test('Test shoot does not damage a tower or a mob outside radius', () => {
          const newTower = A.shoot(tower, world, 0, 20);
          expect(newTower.hp).toBe(100);
        });
      });
      

  });


