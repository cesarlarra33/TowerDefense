// import * as W from "../src/world.js";
// import * as A from "../src/actor.js";
// import * as M from "../src/motor.js";

// const world = W.initializeWorld(35,20);
// W.map_1(world);

// W.showWorld(world);

// let positionInit: A.Point = {x: 0, y: 12};
// let mob1: A.Mob = {velocity: 1, hp: 10};
// let sortMob: A.Sort = {srt: mob1};

// let actor: A.Actor = {id : 1, position: positionInit, sort: sortMob}

// let actor2: A.Actor = M.advance(actor, world);