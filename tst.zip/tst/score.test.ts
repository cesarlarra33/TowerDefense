import * as S from "../src/score";

describe('Score', () => {
    describe('removeLifeFromPlayer', () => {
      test('should decrement playerLives by 1', () => {
        const player: S.Score = { playerLives: 10, money: 100, score: 0 };
        const newPlayer = S.removeLifeFromPlayer(player);
        expect(newPlayer.playerLives).toBe(9);
      });
  
      test('should return a new object', () => {
        const player: S.Score = { playerLives: 10, money: 100, score: 0 };
        const newPlayer = S.removeLifeFromPlayer(player);
        expect(newPlayer).not.toBe(player);
      });
    });
  
    describe('removeMoneyFromPlayer', () => {
      test('should subtract specified amount from money', () => {
        const player: S.Score = { playerLives: 10, money: 100, score: 0 };
        const newPlayer = S.removeMoneyFromPlayer(player, 50);
        expect(newPlayer.money).toBe(50);
      });
  
      test('should return a new object', () => {
        const player: S.Score = { playerLives: 10, money: 100, score: 0 };
        const newPlayer = S.removeMoneyFromPlayer(player, 20);
        expect(newPlayer).not.toBe(player);
      });
    });
  
    describe('addMoneyToPlayer', () => {
      test('should add specified amount to money', () => {
        const player: S.Score = { playerLives: 10, money: 100, score: 0 };
        const newPlayer = S.addMoneyToPlayer(player, 50);
        expect(newPlayer.money).toBe(150);
      });
  
      test('should return a new object', () => {
        const player: S.Score = { playerLives: 10, money: 100, score: 0 };
        const newPlayer = S.addMoneyToPlayer(player, 20);
        expect(newPlayer).not.toBe(player);
      });
    });
  });
  